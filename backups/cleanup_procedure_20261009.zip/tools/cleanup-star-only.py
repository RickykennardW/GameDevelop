"""Audited Star-only cleanup. Plan by default; --apply writes JSON, never blindly deletes."""
import json,copy,re,sys,hashlib,collections
from pathlib import Path
root=Path(__file__).resolve().parent.parent
sp=root/'layouts/game-scene.json';pp=root/'Tower Defense.json'
st=sp.read_text(encoding='utf-8');pt=pp.read_text(encoding='utf-8');s=json.loads(st);p=json.loads(pt)
before=copy.deepcopy(s);beforep=copy.deepcopy(p)
remove={'Tower','ShotgunTower','RocketTower','ArcherTower','Bullet','RocketBullet','ArcherProjectile',
 'AssetShotgunTowerLabel','AssetShotgunTowerPrice','AssetRocketTowerLabel','AssetRocketTowerPrice','AssetCardSeparator',
 'TowerInfoName','TowerInfoDamageLabel','TowerInfoDamage','TowerInfoRateLabel','TowerInfoRate','TowerInfoRangeLabel','TowerInfoRange','TowerInfoDealtLabel','TowerInfoDealt','TowerSellButton','TowerSellLabel','TowerSellValue','TowerInfoCloseHint','ShopScrollTrack','ShopScrollThumb','ShopIndexLabel'}
rename={'ArcherUpgradeIcon':'StarUpgradeIcon'}
def obj(name):return next(o for o in s['objects'] if o['name']==name)
def value(name):return next(v for v in s['variables'] if v['name']==name)
def js(file):return {'type':'BuiltinCommonInstructions::JsCode','inlineCode':(root/'tools'/file).read_text(encoding='utf-8-sig').splitlines(),'parameterObjects':'','useStrict':True}
def group(name,events):return {'type':'BuiltinCommonInstructions::Group','name':name,'events':events}
for name in ['TilePlacement_Indicator','TileType_Button','IndexTowerImage']:
 obj(name)['animations']=[a for a in obj(name)['animations'] if a['name']=='StarCannonTower']
obj('SelectedTowerPreview')['animations']=[a for a in obj('SelectedTowerPreview')['animations'] if a['name'].startswith('SC_')]
obj('ArcherUpgradeIcon')['animations']=[a for a in obj('ArcherUpgradeIcon')['animations'] if a['name'].startswith('SC_')]
for name in ['Enemy','IndexMonsterImage']:obj(name)['animations']=[a for a in obj(name)['animations'] if a['name'].startswith('Nova')]
obj('StarCannonTower')['behaviors']=[];obj('TileType_Button')['behaviors']=[]
for v in obj('TileType_Button')['variables']:
 if v['name']=='TowerType':v['value']='StarCannonTower'
 if v['name']=='Cost':v['value']=300
for name in ['AssetTowerLabel','AssetTowerPrice']:
 o=obj(name)
 if 'string' in o:o['string']='STAR CANNON' if name=='AssetTowerLabel' else '300 GOLD'
s['objects']=[o for o in s['objects'] if o['name'] not in remove]
for o in s['objects']:o['name']=rename.get(o['name'],o['name'])
s['instances']=[i for i in s['instances'] if i['name'] not in remove]
for i in s['instances']:
 i['name']=rename.get(i['name'],i['name'])
 if i['name']=='TileType_Button':
  for v in i.get('initialVariables',[]):
   if v.get('name')=='TowerType':v['value']='StarCannonTower'
   if v.get('name')=='Cost':v['value']=300
def folders(node):
 if isinstance(node,dict) and 'children' in node:
  node['children']=[c for c in node['children'] if c.get('objectName') not in remove]
  for c in node['children']:
   if 'objectName' in c:c['objectName']=rename.get(c['objectName'],c['objectName'])
   folders(c)
folders(s['objectsFolderStructure'])
for g in s['objectsGroups']:g['objects']=[{'name':rename.get(o['name'],o['name'])} for o in g['objects'] if o['name'] not in remove]
s['objectsGroups']=[g for g in s['objectsGroups'] if g['objects']]
s['behaviorsSharedData']=[b for b in s['behaviorsSharedData'] if b['type'] not in {'ButtonStates::ButtonFSM','ButtonStates::ButtonScaleTween','FireBullet::FireBullet','Tween::TweenBehavior','TileMap::TileMapBehavior'}]
value('TowerShopCatalog')['children']=[v for v in value('TowerShopCatalog')['children'] if any(c.get('name')=='Type' and c.get('value')=='StarCannonTower' for c in v['children'])]
value('TowerFootprints')['children']=[v for v in value('TowerFootprints')['children'] if v['name']=='StarCannonTower']
value('SelectionGeometry')['children']=[v for v in value('SelectionGeometry')['children'] if v['name']=='Ground_Decoration']
removevars={'ArcherConfig','LegacyEnemyTypes','LegacyWaveConfigs','WaveConfigs','KillReward','EnemyHP','EnemySpeed','TowerShopScroll','SelectedTowerFound','WorldSelectionHandled'}
s['variables']=[v for v in s['variables'] if v['name'] not in removevars]
# Remove inactive bbox selection fallback and retired panel startup, keep ID/ESC/input edges.
selection=s['events'][3]['events'];s['events'][3]['events']=[selection[i] for i in [0,2,4,5,6]]
s['events'][4]['actions']=[a for a in s['events'][4]['actions'] if not a['type']['value'].startswith('FireBullet::')]
combat=s['events'][10]['events'];s['events'][10]['events']=[e for i,e in enumerate(combat) if i not in [5,6,7,8,10,11]]
s['events'][12]=group('Selected Star Cannon range',[js('selected-range-runtime.js')])
s['events'][14]['events'][0]=js('enemy-healthbar-runtime.js')
s['events'][15]['name']='World presentation and tower components'
s['events'].pop(11) # old tower card scale/tween events
# Generic gameplay-test retained; obsolete prototype/grid/retired-tower tests removed.
p['tests']=[p['tests'][0]];p['tests'][0]['name']='Picking Star Cannon';p['tests'][0]['description']='Star Cannon selection toggles the single placement builder.'
p['tests'][0]['lastRunStatus']='not-run';p['tests'][0]['lastRunAt']=0
p['tests'][0]['source']=[line.replace('const button = buttons[0];','harness.assert(buttons.length === 1, "Only Star Cannon is available.");\nconst button = buttons[0];') for line in p['tests'][0]['source']]
p['eventsFunctionsExtensions']=[r for r in p['eventsFunctionsExtensions'] if r['referenceTo']=='/eventsFunctionsExtensions/health']
# Embed all reviewed source modules at the cleaned locations.
mapping=[(0,(0,),'responsive-map-runtime.js'),(0,(1,),'island-map-runtime.js'),(1,(0,),'unit-index-runtime.js'),(1,(1,),'selected-panel-runtime.js'),(1,(2,),'obstacle-panel-runtime.js'),(3,(0,),'world-selection-runtime.js'),(6,(),'free-placement-runtime.js'),(9,(0,),'free-placement-click.js'),(10,(0,1),'nova-wisp-runtime.js'),(10,(1,),'nova-wave-manager.js'),(10,(2,),'nova-spawn-runtime.js'),(10,(3,0),'nova-movement-runtime.js'),(10,(5,),'star-cannon-runtime.js'),(10,(6,),'nova-death-runtime.js'),(11,(0,),'selected-range-runtime.js'),(13,(0,),'enemy-healthbar-runtime.js'),(14,(0,),'island-render-runtime.js'),(16,(0,),'free-placement-rings.js')]
for index,children,file in mapping:
 e=s['events'][index]
 for child in children:e=e['events'][child]
 assert e['type']=='BuiltinCommonInstructions::JsCode',(file,e['type'])
 e['inlineCode']=(root/'tools'/file).read_text(encoding='utf-8-sig').splitlines()
# References include scene config, panel/tiled textures, events, project properties, not only sprites.
resources={r['name']:r for r in p['resources']['resources']};refs=collections.defaultdict(set)
def scan(x,owner):
 if isinstance(x,dict):
  for y in x.values():scan(y,owner)
 elif isinstance(x,list):
  for y in x:scan(y,owner)
 elif isinstance(x,str):
  if x in resources:refs[x].add(owner)
  if 'getPIXITexture' in x:
   for name in resources:
    if name in x:refs[name].add(owner)
for o in s['objects']:scan({k:v for k,v in o.items() if k!='name'},'object:'+o['name'])
scan(s['events'],'events');scan(s['variables'],'scene config');scan(p['properties'],'project properties');scan(p['objects'],'global objects')
audit=[]
for name,r in resources.items():
 users=sorted(refs[name]);status='SHARED' if len(users)>1 else 'KEEP' if users else 'REMOVE'
 audit.append({'name':name,'file':r['file'],'status':status,'consumers':users,'bytes':(root/r['file']).stat().st_size,'reason':'live dependency' if users else 'no reference after scoped object/animation/event cleanup'})
p['resources']['resources']=[r for r in p['resources']['resources'] if refs[r['name']]]
usedfiles={str((root/r['file']).resolve()) for r in p['resources']['resources']}
# A map-authoring source is the exact bitmap embedded4times in terrain-repeat.svg.
sourceTerrain=(root/'assets/celestial_void/island/Terrain.png').resolve();keepSource={str(sourceTerrain)}
delete=[]
for path in [*list((root/'assets').rglob('*')),*list((root/'Default size').rglob('*')),root/'Index_Logo.png',root/'Ornate Fantasy Atlas Index Book.png']:
 if not path.is_file():continue
 resolved=path.resolve();assert resolved.is_relative_to(root)
 if str(resolved) in usedfiles or str(resolved) in keepSource:continue
 if path.suffix.lower() in ['.png','.svg','.wav','.jpg','.jpeg','.webp'] or 'archer' in path.parts:
  delete.append({'path':path.relative_to(root).as_posix(),'bytes':path.stat().st_size,'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'reason':'orphaned physical asset after dependency audit'})
plan={'removeObjects':sorted(remove),'renamedSharedObject':rename,'removeVariables':sorted(removevars),'resources':audit,'deleteAssets':delete,'keepAuthoringSource':sourceTerrain.relative_to(root).as_posix(),'objectsAfter':len(s['objects']),'resourcesAfter':len(p['resources']['resources']),'runtimeSourceMapping':mapping,'removedCombatChildren':[5,6,7,8,10,11]}
out=root/'tools/cleanup-audit';out.mkdir(exist_ok=True);(out/'dependency-plan.json').write_text(json.dumps(plan,indent=2),encoding='utf-8')
def save(path,source,data,keys):
 decoder=json.JSONDecoder();cur=1;replacements=[]
 while cur<len(source):
  while source[cur].isspace() or source[cur]==',':cur+=1
  if source[cur]=='}':break
  k,n=decoder.raw_decode(source[cur:]);cur+=n
  while source[cur].isspace() or source[cur]==':':cur+=1
  _,n=decoder.raw_decode(source[cur:])
  if k in keys:replacements.append((cur,n,json.dumps(data[k],indent=2,ensure_ascii=False).replace('\n','\n  ')))
  cur+=n
 for cur,n,text in reversed(replacements):source=source[:cur]+text+source[cur+n:]
 assert json.loads(source)==data;path.write_text(source,encoding='utf-8')
if '--apply' in sys.argv:
 save(sp,st,s,{'objects','instances','objectsFolderStructure','objectsGroups','variables','events','behaviorsSharedData'})
 save(pp,pt,p,{'resources','tests','eventsFunctionsExtensions'})
 (out/'source-mapping.json').write_text(json.dumps(mapping,indent=2),encoding='utf-8')
print('PLAN',len(remove),'objects;',len([r for r in audit if r['status']=='REMOVE']),'resources;',len(delete),'physical asset files;',sum(d['bytes'] for d in delete),'asset bytes; apply=', '--apply' in sys.argv)
